$Id: README.txt,v 1.1 2004/12/29 03:56:57 cxh Exp $
See package.html
