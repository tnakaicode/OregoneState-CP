$Id: README.txt,v 1.1 2002/07/09 15:53:56 cxh Exp $
ptolemy/plot/servlet/README.txt

This directory contains sample code to use Ptplot as a servlet.

The code was written by Alberto Gobbi, and has _not_ been tested
by the Ptplot pteam at UC Berkeley.

